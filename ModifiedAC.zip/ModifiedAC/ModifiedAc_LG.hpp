
#ifndef AC_LG_HPP
#define AC_LG_HPP
//#include <Arduino.h>

//#define INFO // save program space and suppress info output from the LG-AC driver.
//#define DEBUG // for more output from the LG-AC driver.
#include "IRremoteInt.h"
#include "ac_LG.h" // useful constants
#include "LongUnion.h"
#define SIZE_OF_FAN_SPEED_MAPPING_TABLE     4

const int AC_FAN_WALL[SIZE_OF_FAN_SPEED_MAPPING_TABLE] = { 0, 2, 4, 5 }; // 0 -> low, 4 high, 5 -> cycle



void Aircondition_LG::printMenu(Print *aSerial) {
    aSerial->println();
    aSerial->println();
    aSerial->println(F("Type command and optional parameter without a separator"));
    aSerial->println(F("0 Off"));
    aSerial->println(F("1 On"));
    aSerial->println(F("t Temperature <18 to 30> degree"));
    aSerial->println(F("+ Temperature + 1"));
    aSerial->println(F("- Temperature - 1"));
    aSerial->println(F("e.g. \"s1\" or \"t23\" or \"mc\" or \"O60\" or \"+\""));
    aSerial->println(F("No plausibility check is made!"));
    aSerial->println();
}

/*
 * Send repeat
 * Repeat commands should be sent in a 110 ms raster.
 * @param aCommand one of LG_COMMAND_OFF, LG_COMMAND_ON etc.
 */
bool Aircondition_LG::sendCommandAndParameter(char aCommand, int aParameter) {
    // Commands without parameter
    switch (aCommand) {
    case LG_COMMAND_OFF: // off
        sendIRCommand(LG_POWER_DOWN);
        PowerIsOn = false;
        return true;

    case LG_COMMAND_ON: // on
        PowerIsOn = false; // set to false in order to suppress on bit
        sendTemperatureFanSpeedAndMode();
        return true;

    case LG_COMMAND_TEMPERATURE_PLUS:
        if (18 <= Temperature && Temperature <= 29) {
            Temperature++;
            sendTemperatureFanSpeedAndMode();
        } else {
            return false;
        }
        return true;

    case LG_COMMAND_TEMPERATURE_MINUS:
        if (19 <= Temperature && Temperature <= 30) {
            Temperature--;
            sendTemperatureFanSpeedAndMode();
        } else {
            return false;
        }
        return true;
    // Requires parameter
    case LG_COMMAND_FAN_SPEED:
        if (aParameter < SIZE_OF_FAN_SPEED_MAPPING_TABLE) {
            FanIntensity = aParameter;
            sendTemperatureFanSpeedAndMode();
        } else {
            return false;
        }
        break;
    
    }
}
void Aircondition_LG::sendIRCommand(uint16_t aCommand) {

    IR_INFO_PRINT(F("Send code=0x"));
    IR_INFO_PRINT(aCommand, HEX);
    IR_INFO_PRINT(F(" | 0b"));
    IR_INFO_PRINTLN(aCommand, BIN);

    IrSender.sendLG((uint8_t) LG_ADDRESS, aCommand, 0, false, useLG2Protocol);
}

/*
 * Takes values from static variables
 */
void Aircondition_LG::sendTemperatureFanSpeedAndMode() {

    uint8_t tTemperature = Temperature;
    IR_INFO_PRINT(F("Send temperature="));
    IR_INFO_PRINT(tTemperature);
    IR_INFO_PRINT(F(" fan intensity="));
    IR_INFO_PRINT(FanIntensity);
    IR_INFO_PRINT(F(" mode="));
    IR_INFO_PRINTLN((char )Mode);

    WordUnion tIRCommand;
    tIRCommand.UWord = 0;

    // Temperature is coded in the upper nibble of the LowByte
    tIRCommand.UByte.LowByte = ((tTemperature - 15) << 4); // 16 -> 0x00, 18 -> 0x30, 30 -> 0xF0

    // Fan intensity is coded in the lower nibble of the LowByte Set fan Value
    tIRCommand.UByte.LowByte |= AC_FAN_WALL[2]; //change fan intensity to constant 4
    
    switch (Mode) {
    case AC_MODE_COOLING:
        tIRCommand.UByte.HighByte = LG_MODE_COOLING >> 8;
        break;
    }
    if (!PowerIsOn) {
        // switch on requires masked bit
        tIRCommand.UByte.HighByte &= ~(LG_SWITCH_ON_MASK >> 8);
    }
    PowerIsOn = true;

    sendIRCommand(tIRCommand.UWord);
}

/** @}*/
#endif // #ifndef AC_LG_HPP
#pragma once