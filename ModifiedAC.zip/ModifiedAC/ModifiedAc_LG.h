
#ifndef AC_LG_H
#define AC_LG_H

#include <Arduino.h>

/** \addtogroup Airconditoners Air conditioner special code
 * @{
 */

#define LG_ADDRESS  0x88

/*
 * The basic IR command codes
 * Parts of the codes (especially the lower nibbles) may be modified to contain
 * additional information like temperature, fan speed and minutes.
 */
#define LG_SWITCH_ON_MASK       0x0800  // This bit is masked if we switch Power on
#define LG_MODE_COOLING         0x0800
#define LG_POWER_DOWN           0xC005
#define LG_SLEEP                0xA000  // relative minutes in lower nibbles
#define LG_WALL_SWING_ON        0x1314
#define LG_WALL_SWING_OFF       0x1315
#define LG_SWING_ON             0x1316  // not verified, for AKB73757604
#define LG_SWING_OFF            0x1317  // not verified, for AKB73757604

/*
 * Commands as printed in menu and uses as first parameter for sendCommandAndParameter
 */
#define LG_COMMAND_OFF          '0'
#define LG_COMMAND_ON           '1'
#define LG_COMMAND_SWING        's'
#define LG_COMMAND_SLEEP        'S'
#define LG_COMMAND_FAN_SPEED    'f'
#define LG_COMMAND_TEMPERATURE  't'
#define LG_COMMAND_TEMPERATURE_PLUS '+'
#define LG_COMMAND_TEMPERATURE_MINUS '-'
#define LG_COMMAND_TIMER_ON     'T'
#define LG_COMMAND_TIMER_OFF    'O'

/*
 * The modes are encoded as character values for easy printing :-)
 */
#define AC_MODE_COOLING         'c'

// see https://github.com/crankyoldgit/IRremoteESP8266/blob/master/src/ir_LG.h
union LGProtocol {
    uint32_t raw;  ///< The state of the IR remote in IR code form.
    struct {
        uint32_t Checksum :4;
        uint32_t Fan :3;
        uint32_t FanExt :1;
        uint32_t Temp :4;
        uint32_t Mode :4;
        uint32_t Function :3;
        uint32_t SwitchOnMask :1; /* Content is 0 when switching from off to on */
        uint32_t Signature :8; /* Content is 0x88, LG_ADDRESS */
    };
};

class Aircondition_LG {
public:
    bool sendCommandAndParameter(char aCommand, int aParameter);
    void printMenu(Print *aSerial);
    void sendIRCommand(uint16_t aCommand);
    void sendTemperatureFanSpeedAndMode();
    /*
     * Internal state of the air condition
     */

    bool PowerIsOn;

    // These value are encoded and sent by AC_LG_SendCommandAndParameter()
    uint8_t FanIntensity = 1;    // 0 -> low, 4 high, 5 -> cycle
    uint8_t Temperature = 22;    // temperature : 18 ~ 30
    uint8_t Mode = AC_MODE_COOLING;
    bool useLG2Protocol = false;
};

/** @}*/
#endif // #ifndef AC_LG_H
#pragma once